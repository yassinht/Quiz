package com.example.quiz1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Result extends AppCompatActivity {
String res;
String s,name;
TextView  finalres;
TextView txt ;
Button btn1 , again,quit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        TextView finalres = findViewById(R.id.finalres);
        TextView txt = findViewById(R.id.txt);
        Button btn1=findViewById(R.id.btn1);
        Button again=findViewById(R.id.again);
        Button quit=findViewById(R.id.quit);
        name= getIntent().getStringExtra("name");
        txt.setText(name);


        res = getIntent().getStringExtra("r");
        finalres.setText(String.valueOf(res));
        finalres.setText("your score is"            + res);
        Integer number = Integer.valueOf(res);

        if (number < 10) {
            finalres.setText("your score is :"            + res       );
            finalres.setTextColor(getResources().getColor(R.color.purple_200));
        } else {
            finalres.setTextColor(getResources().getColor(R.color.teal_200));
        }

        Toast.makeText(this, "le score est" + res, Toast.LENGTH_SHORT).show();
      btn1.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              gotoUrl( "https://mail.google.com/mail/u/0/#inbox?compose=new");

          }
      });



      again.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
           Intent   i = new Intent(Result.this,MainActivity.class);
           startActivity(i);
          }
      });
      quit.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              finishAffinity();

          }
      });




      }
    private void gotoUrl(String s){
        Uri uri= Uri.parse(s);
        startActivity(new Intent(Intent.ACTION_VIEW,uri));
    }


    }

