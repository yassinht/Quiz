package com.example.quiz1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity2 extends AppCompatActivity {

TextView name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Button bt=findViewById(R.id.bt);
        TextView name=findViewById(R.id.name);
        String n= getIntent().getStringExtra("name");
        name.setText("hello "+n);


        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioGroup group=findViewById(R.id.group);
                RadioButton geo=findViewById(R.id.geo);
                RadioButton spt=findViewById(R.id.spt);
                RadioButton his=findViewById(R.id.his);
                TextView edit1=findViewById(R.id.edit1);
                if (spt.isChecked()) {
                    Intent i = new Intent(MainActivity2.this, Sport1.class);
                    startActivity(i);
                }

                else if  (geo.isChecked()){
                    Intent i = new Intent(MainActivity2.this,Geo1.class);

                    startActivity(i);
                }
                else if (his.isChecked()){

                    Intent i = new Intent(MainActivity2.this,Histoire1.class);

                    startActivity(i);

                }


            };

        });
    }
}