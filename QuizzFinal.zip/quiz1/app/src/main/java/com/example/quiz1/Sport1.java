package com.example.quiz1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Sport1 extends AppCompatActivity {
    Button suivant,rp;
    RadioGroup rg;
    RadioButton rb;
    int res;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sport1);
        Button suivant=findViewById(R.id.suivant);
        Button rp=findViewById(R.id.rp);
        RadioGroup gr = findViewById(R.id.gr);
        RadioButton radioButton1 = findViewById(R.id.radioButton1);
        RadioButton radioButton2 = findViewById(R.id.radioButton2);
        RadioButton radioButton3 = findViewById(R.id.radioButton3);

           rp.setOnClickListener(new View.OnClickListener() {
                          @Override
                          public void onClick(View v) {
                              if (radioButton1.isChecked()) {
                                 radioButton1.setTextColor(getResources().getColor(R.color.teal_200));
                                  radioButton2.setTextColor(getResources().getColor(R.color.purple_200));
                                  radioButton3.setTextColor(getResources().getColor(R.color.purple_200));
                              } else if (radioButton2.isChecked()) {
                                  radioButton1.setTextColor(getResources().getColor(R.color.teal_200));
                                  radioButton2.setTextColor(getResources().getColor(R.color.purple_200));
                                  radioButton3.setTextColor(getResources().getColor(R.color.purple_200));
                              }
                              else
                              {
                                  radioButton1.setTextColor(getResources().getColor(R.color.teal_200));
                                  radioButton2.setTextColor(getResources().getColor(R.color.purple_200));
                                  radioButton3.setTextColor(getResources().getColor(R.color.purple_200));


                              }


                          }

                          ;
                      });
rp.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        radioButton1.setTextColor(getResources().getColor(R.color.purple_200));
        radioButton2.setTextColor(getResources().getColor(R.color.teal_200));
        radioButton3.setTextColor(getResources().getColor(R.color.purple_200));
    }
});
        suivant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (radioButton2.isChecked()) {
                    res =res+5;
                }
                else {
                    res =res+0;
                }
                Intent i = new Intent(Sport1.this, Sport2.class);
                i.putExtra("res",res);
                startActivity(i);



            }
        });


    };
};