package com.example.quiz1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class Histoire2 extends AppCompatActivity {
Button suivant2,rp;
int res;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_histoire2);
         Button suivant2=findViewById(R.id.suivant2);
         Button rp=findViewById(R.id.rp);
        res=getIntent().getExtras().getInt("res");
        RadioButton radioButton1 = findViewById(R.id.radioButton1);
        RadioButton radioButton2 = findViewById(R.id.radioButton2);
        RadioButton radioButton3 = findViewById(R.id.radioButton3);
        rp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        rp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                radioButton1.setTextColor(getResources().getColor(R.color.teal_200));
                radioButton2.setTextColor(getResources().getColor(R.color.purple_200));
                radioButton3.setTextColor(getResources().getColor(R.color.purple_200));
            }
        });
        Toast.makeText(this, "le score est"+res,Toast.LENGTH_SHORT).show();
         suivant2.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 if (radioButton1.isChecked()) {
                     res =res+5;
                 }
                 else {
                     res =+res+0;
                 }
                 Intent i = new Intent(Histoire2.this, Histoire3.class);
                 i.putExtra("res",res);
                 startActivity(i);
             }
         });
    }
}