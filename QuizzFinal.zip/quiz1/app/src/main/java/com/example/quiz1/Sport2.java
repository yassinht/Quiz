package com.example.quiz1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

   public class Sport2 extends AppCompatActivity {


    Button suivant2 ,rp;

       RadioGroup group ;
      int res ;


       @Override
  protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sport2);

        RadioGroup group = findViewById(R.id.group);
        RadioButton rb1 = findViewById(R.id.rb1);
        RadioButton rb2 = findViewById(R.id.rb2);
        RadioButton rb3 = findViewById(R.id.rb3);


           res=getIntent().getExtras().getInt("res");
        Button suivant2=findViewById(R.id.suivant2);
        Button rp=findViewById(R.id.rp);

        rp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


            }
        });
        rp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rb1.setTextColor(getResources().getColor(R.color.teal_200));
                rb2.setTextColor(getResources().getColor(R.color.purple_200));
                rb3.setTextColor(getResources().getColor(R.color.purple_200));
            }
        });
        Toast.makeText(this, "le score est"+res,Toast.LENGTH_SHORT).show();

        suivant2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {




                if (rb1.isChecked()) {
                    res =res+5;
                }
                else {
                    res =+res+0;
                }


                Intent i = new Intent(Sport2.this, Sport3.class);
                i.putExtra("res", res);
                startActivity(i);






            }
        });
    }
}